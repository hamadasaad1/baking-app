package com.hamada.android.baking.internet;

public interface Routes {
    //this is base uel to get data from server
    String BASE_URL = "https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/";

    String END_URL="baking.json";
}
